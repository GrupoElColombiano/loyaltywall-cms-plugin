<?php
// Silences is golden