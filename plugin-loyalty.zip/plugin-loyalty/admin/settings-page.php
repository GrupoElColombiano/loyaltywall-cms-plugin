<?php

// Crear el menú de configuración en el admin
function plugin_loyaltywall_menu() {
    add_menu_page(
        'Configuración LoyaltyWall', 
        'LoyaltyWall', 
        'manage_options', 
        'plugin_loyaltywall', 
        'plugin_loyaltywall_settings_page', 
        'dashicons-admin-generic', 
        100
    );
}

// Renderizar la página de configuración
function plugin_loyaltywall_settings_page() {
    ?>
    <div class="wrap">
        <h1>Configuración del Plugin LoyaltyWall</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('plugin_loyaltywall_settings');
            do_settings_sections('plugin_loyaltywall');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Registrar los ajustes y campos
function plugin_loyaltywall_register_settings() {
    register_setting('plugin_loyaltywall_settings', 'plugin_loyaltywall_url_base');
    register_setting('plugin_loyaltywall_settings', 'plugin_loyaltywall_url_base_loyaltiwall');
    register_setting('plugin_loyaltywall_settings', 'plugin_loyaltywall_url_backend_admin');
    add_settings_section(
        'plugin_loyaltywall_section', 
        'Ajustes Generales', 
        null, 
        'plugin_loyaltywall'
    );

    add_settings_field(
        'plugin_loyaltywall_url_base', 
        'URL Base', 
        'plugin_loyaltywall_url_base_field_callback', 
        'plugin_loyaltywall', 
        'plugin_loyaltywall_section'
    );

    add_settings_field(
        'plugin_loyaltywall_url_base_loyaltiwall', 
        'URL Base Loyaltywall', 
        'plugin_loyaltywall_url_base_loyaltiwall_field_callback', 
        'plugin_loyaltywall', 
        'plugin_loyaltywall_section'
    );
    
    add_settings_field(
        'plugin_loyaltywall_url_backend_admin', 
        'URL Backend Admin', 
        'plugin_loyaltywall_url_backend_admin_field_callback', 
        'plugin_loyaltywall', 
        'plugin_loyaltywall_section'
    );
}

// Callbacks para los campos de configuración
function plugin_loyaltywall_url_base_field_callback() {
    $url_base = get_option('plugin_loyaltywall_url_base', '');
    echo "<input type='text' name='plugin_loyaltywall_url_base' value='" . esc_attr($url_base) . "' class='regular-text'>";
}

function plugin_loyaltywall_url_base_loyaltiwall_field_callback() {
    $url_base_loyaltiwall = get_option('plugin_loyaltywall_url_base_loyaltiwall', '');
    echo "<input type='text' name='plugin_loyaltywall_url_base_loyaltiwall' value='" . esc_attr($url_base_loyaltiwall) . "' class='regular-text'>";
}

function plugin_loyaltywall_url_backend_admin_field_callback() {
    $url_backend_admin = get_option('plugin_loyaltywall_url_backend_admin', '');
    echo "<input type='text' name='plugin_loyaltywall_url_backend_admin' value='" . esc_attr($url_backend_admin) . "' class='regular-text'>";
}


