<?php
/*
 * Plugin Name:       Paywall Javascript
 * Plugin URI:        https://www.elcolombiano.com/
 * Description:       Plugin para cargar el paywall javascript
 * Version:           0.0.1
 * Author:            El Colombiano
*/

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Incluir archivos necesarios
require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/enqueue-scripts.php';

// 1. Crear el menú de configuración
add_action('admin_menu', 'plugin_loyaltywall_menu');

// 2. Registrar los ajustes
add_action('admin_init', 'plugin_loyaltywall_register_settings');

// 3. Encolar los scripts y pasar variables al JS
add_action('wp_enqueue_scripts', 'cargar_loyaltywall_script_js');
