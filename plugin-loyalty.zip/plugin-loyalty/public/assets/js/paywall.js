const Version = '1.0.2'
const url_base = configuracion.url_base;
const url_base_loyaltiwall = configuracion.url_base_loyaltiwall;
// Esperar a que el documento esté listo para interactuar con él
document.addEventListener("DOMContentLoaded", function () {
    const scriptElement = document.createElement("script");
    scriptElement.src = "https://cdn.jsdelivr.net/npm/keycloak-js@22.0.5/dist/keycloak.min.js";
    scriptElement.onload = function() {
        const _kc = new Keycloak({
            url: "https://auth.loyaltywall.com/",
            realm: "loyaltywall-client-prod",
            clientId: "paywall-login"
        });

        window._kc = _kc;

        // Accediendo al JSON-LD por su ID
        var jsonLdScript = document.getElementById("jsonLd");
        if (jsonLdScript) {
 
            // Obteniendo el contenido del script como texto
            var jsonLdContent = jsonLdScript.textContent || jsonLdScript.innerText;
            // Analiza el contenido JSON-LD para convertirlo en un objeto JavaScript
            var jsonLdObject = JSON.parse(jsonLdContent);
            var site;
 
            if(!jsonLdObject["hasPart"].length) {
                if(jsonLdObject["hasPart"]["@type"].includes("Product")){
                    var item = jsonLdObject["hasPart"];
                    site = item.name;
                }
            }else{
                jsonLdObject.hasPart.forEach(item => {
                    // Verifica si el elemento tiene "@type" y es un "Product"
                    if (Array.isArray(item["@type"]) && item["@type"].includes("Product")) {
                    // Accede a las propiedades específicas del "Product"
                        site = item.name;
                    }
                });
            }
            initKeyCloak(_kc, jsonLdScript, site, jsonLdObject);
            createFloatingElements(_kc, jsonLdObject);
        }
    };
 
    document.head.appendChild(scriptElement);   
    
});
 

function decodedJWT(token) {
    // Dividir el token en sus tres partes (header, payload, signature)
    const partes = token.split(".");

    // La segunda parte es el payload (carga útil)
    const payload = partes[1];
    let base64Str =payload; // tu cadena aquí
    base64Str = base64Str.replace(/-/g, '+').replace(/_/g, '/');
    
    // Decodificar el Base64
    const jsonPayload = decodeURIComponent(atob(base64Str).split("").map(function(c) {
        return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(""));

    // Convertir el JSON en un objeto JavaScript
    return JSON.parse(jsonPayload);
}

async function initKeyCloak(_kc, jsonLdScript, site, jsonLdObject) {
    _kc.init({
        onload: "login-required",
        checkLoginIframe: false,
    }).then((authenticated) => {
        if (authenticated) {
            const token = _kc.token;
            localStorage.setItem(site+"_token", token);
            const userData = _kc.tokenParsed;
            localStorage.setItem(site+"_user_data", JSON.stringify(userData));

            loginEvent(jsonLdObject, site).then(response => console.log("✅ login event ✅", response)).catch(error => console.log("❌ login event ❌", error ));
            validateStatusButton(authenticated, site);
            paywallExecute(_kc, jsonLdScript, site, authenticated);
        }else{
            paywallExecute(_kc, jsonLdScript, site, authenticated);
        }

    }).catch((onrejected) => console.error("❌ authentication error ❌", onrejected));

}

async function loginEvent(jsonLdObject, site) {
    const getToken = localStorage.getItem(site+"_token");
    const infoScope = decodedJWT(getToken);

    const urlSite = jsonLdObject["isPartOf"].productID;
    const domain = urlSite.split("/");

    const urlToCDPReport = `${url_base_loyaltiwall}/paywall/login`;

    const requesOptions = {
        method: "POST",
        headers: {
            Authorization: `Bearer ${getToken}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            source: {
                itemId: jsonLdObject?.articleSection,
                itemType: "site",
                scope: domain[2]
            },
            properties: infoScope,
            target: {
                itemType: "page",
                scope: domain[2],
                itemId: "homepage",
                properties: {
                    pageInfo: {
                        referringURL: urlSite
                    }
                }
            }
        })
    };

    try {
        let respuesta = await fetch(urlToCDPReport, requesOptions);
        let datos = await respuesta.json();
        if(datos.profileId){
            localStorage.setItem("id_kc", datos.profileId)
        }
        return datos;
    } catch (error) {
        // Manejando errores si la promesa falla
        console.error("Error:", error);
    }
}

function createFloatingElements(_kc, jsonLdObject) {

    const urlSite = jsonLdObject["isPartOf"].productID;
    const styleElement = document.createElement("style");
    styleElement.type = "text/css";
    styleElement.appendChild(document.createTextNode(styleButtonAuth));
    document.head.appendChild(styleElement);

    const container = document.createElement("div");
    container.classList.add("floating-element");
    document.body.appendChild(container);

    const button1 = document.createElement("button");
    button1.textContent = "Iniciar Sesión";
    button1.classList.add("floating-button");
    button1.id = "paywall-login-button"; // Asignando el ID "login-button" al botón
    button1.addEventListener("click", function() {
        _kc.login();
    });
    container.appendChild(button1);

    const button2 = document.createElement("button");
    button2.textContent = "Cerrar Sesión";
    button2.classList.add("floating-button");
    button2.id = "paywall-logout-button"; // Asignando el ID "login-button" al botón
    button2.addEventListener("click", function() {
        window.localStorage.clear();
        _kc.logout({
            redirectUri: urlSite
        });
    });
    container.appendChild(button2);

}

function login() {
    _kc.login()
}

function validateStatusButton(authenticated, siteCurrent){
    const loginButton = document.getElementById("paywall-login-button");
    const logoutButton = document.getElementById("paywall-logout-button");
    if(localStorage.getItem(siteCurrent+"_token")){
        if (logoutButton) {
            logoutButton.style.display = 'block'; // Esto ocultará el botón
        }

        if (loginButton) {
            loginButton.style.display = 'none'; // Esto ocultará el botón
        }
    }else{

        if (logoutButton) {
            logoutButton.style.display = 'none'; // Esto ocultará el botón
        }

        if (loginButton) {
            loginButton.style.display = 'block'; // Esto ocultará el botón
        }

    }

}

const comment_callback = function(){
    commentSectionEventFacebook()
}
  
  // Inicializar SDK de Facebook cuando el SDK esté listo
  window.fbAsyncInit = function() {

    FB.init({
        appId      : '384211001414287',
        cookie     : true,
        status    : true,
        xfbml      : true,
        version    : 'v20.0'
      });

    FB.Event.subscribe('comment.create', comment_callback);
};

async function commentSectionEventFacebook() {
    let site;
    let itemId;
    var jsonLdScript = document.getElementById("jsonLd");
    
    if (jsonLdScript) {

        // Obteniendo el contenido del script como texto
        var jsonLdContent = jsonLdScript.textContent || jsonLdScript.innerText;
        // Analiza el contenido JSON-LD para convertirlo en un objeto JavaScript
        const jsonLdObject = JSON.parse(jsonLdContent);
        

        if(!jsonLdObject["hasPart"].length) {
            if(jsonLdObject["hasPart"]["@type"].includes("Product")){
                var item = jsonLdObject["hasPart"];
                site = item.name;
                itemId = jsonLdObject?.name
            }
        }else{
            jsonLdObject.hasPart.forEach(item => {
                // Verifica si el elemento tiene "@type" y es un "Product"
                if (Array.isArray(item["@type"]) && item["@type"].includes("Product")) {
                // Accede a las propiedades específicas del "Product"
                    site = item.name; 
                }
            });
        }
    }

    const getToken = localStorage.getItem(site+"_token");
    const userData = localStorage.getItem(site+"_user_data");
    const infoScope ={
        "usuario":{
            "correo":userData.email,
            "nombres":userData.given_name,
            "apellidos":userData.family_name,
            "identificacion":"98765412",
            "celular":"3001111222"
        },
        "plataforma": "Facebook",
        "interaccion": "Comentar"
};
    const urlSite = site;
    const domain = urlSite.split("/");

    const urlToCDPReport = `${url_base_loyaltiwall}/paywall/socialMedia`;

    const requesOptions = {
        method: "POST",
        headers: {
            Authorization: `Bearer ${getToken}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            source: {
                itemId: itemId,
                itemType: "site",
                scope: domain[2]
            },
            properties: infoScope,
            target: {
                itemType: "page",
                scope: domain[2],
                itemId: "homepage",
                properties: {
                    pageInfo: {
                        referringURL: urlSite
                    }
                }
            }
        })
        
    };
    try {
        let respuesta = await fetch(urlToCDPReport, requesOptions);
        let datos = await respuesta.json();
        return datos;
    } catch (error) {
        console.error("Error:", error);
    }
   
}




  

const template =
  "<div id='miModal' class='modal-paywall'>" +
  "<div class='modal-content'>" +
  //"<span class='close' onclick='cerrarModal()'>&times;</span>" +
  "<div class='plan-message'>¡Gracias por disfrutar de nuestro contenido!</div>" +
  "<div class='content-info'>" +
    "<p class='text-descriptive'> Parece que has alcanzado el límite de visualizaciones gratuitas. Para seguir explorando nuestro \n contenido exclusivo. te invitamos a registrarte o suscribirte para acceder a más contenido exclusivo.</p>"+
    "<p class='text-call-action'>¡Regístrate o suscríbete ahora para seguir disfrutando de la mejor experiencia!</p>"+
    "<div class='buttons-container'>"+
    "<button onclick='login()'>Inicia sesión</button>"+
    "<button onclick='login()'>Suscríbete!</button>" +
    "</div>" +
  "</div>"+
  '</div>' +
  '</div>';

var styles = `
    .content-info {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px 40px;
    }
    
    .text-descriptive{
        font-size: 16px;
        line-height: 22px;
        word-break: keep-all;
        overflow-wrap: break-word;
        hyphens: none;
        margin: 5px 0;
        text-align: center;
        font-weight: 400;
    }

    .buttons-container {
        margin: 15px 0px;
        width: 100%;
        justify-content: center;
        display: flex;
    }

    .buttons-container> button {
        width: 220px;
        border-radius: 8px;
        margin: 0px 15px;
        padding: 10px;
        cursor: pointer;
    }

    .buttons-container > button:first-child {
        background-color: #fff;
        font-size: 14px;
        border: 1px solid #C9D315;
        font-weight: 700;
        color: #000;
    }

    .buttons-container > button:nth-child(2) {
        background-color: #C9D315;
        font-size: 14px;
        border: 1px solid #C9D315;
        font-weight: 700;
        color: #000;
    }

    .text-call-action{
         margin: 5px 0;
        font-size: 18px;
        text-align: center;
        line-height: 28px;
        font-weight: 600;
    }

    .color-box {
      width: calc(33.33% - 10px);
      height: 300px;
      display: inline-flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin-right: 10px;
      box-sizing: border-box;
      text-align: center;
      border: 1px solid #888; /* Borde de 2px */
      margin-bottom: 10px; /* Espacio entre los divs de plan */
      position: relative; /* Para que la posición absoluta del icono sea relativa a este div */
    }


    .plan-message {
        text-align: center;
        font-size: 18px;
        margin-bottom: 20px;
        font-family: sans-serif;
        font-style: inherit;
        font-weight: bold;
        background-color: #C9D315;
        border-top-left-radius: 16px;
        border-top-right-radius: 16px;
        padding: 16px;
    }

    .color-box span {
      color: white; /* Ajusta el color del texto según el fondo del div */
    }

    .modal-paywall {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.7);
      z-index: 9999;
    }

    .modal-content {
        background-color: #fefefe;
        margin: 10% auto;
        border: 1px solid #888;
        width: 80%;
        position: relative;
        border-radius: 16px;
        border-bottom: 8px solid black;
    }

    .close {
      position: absolute;
      top: 0;
      right: 0;
      padding: 10px;
      cursor: pointer;
    }

    .modal-open {
      overflow: hidden;
    }
`;

const styleButtonAuth = `
    .floating-element {
      position: fixed;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      z-index: 10000;
    }

    .floating-element button,
    .floating-element div {
      margin-bottom: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .floating-button {
      padding: 10px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .floating-button:hover {
      background-color: #2980b9;
    }

    .floating-div {
      width: 100px;
      height: 100px;
      background-color: #e74c3c;
      border-radius: 5px;
    }
`;
// Función para simular la compra (puedes ajustar esta función según tus necesidades)
function comprarPlan(plan) {
  alert('¡Plan ' + plan + ' comprado!');
}