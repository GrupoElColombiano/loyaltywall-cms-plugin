const admin_api = configuracion.url_api_admin

async function paywallExecute(_kc, jsonLdScript, siteCurrent, authenticated){
    validateStatusButton(authenticated, siteCurrent);
    // Accediendo al header directamente
    let type = "";
    let site = "";
    let identifier = "";
    let category = ""
    let articleSection = ""
    let currentDateArticle = 0;
    let isAccessibleForFree = false;
    const currentDate = new Date();
    let userType = ""
    let userIdCurrent = getOrSetUniqueId();
    const getToken = localStorage.getItem(siteCurrent+"_token")
    if(getToken){
        const jwt = decodedJWT(getToken)
        userType = "registrado"
        userIdCurrent = jwt.sub
    }else{
        userType = "anonimo"
    }

    // Obtener la fecha actual
    const today = new Date();

    // Obtener el año actual
    const year = today.getFullYear();

    // Crear una nueva fecha para el 1 de enero del mismo año
    const startOfYear = new Date(year, 0, 1);

    // Calcular la diferencia en milisegundos entre la fecha actual y el 1 de enero
    const timeDifference = today - startOfYear;

    // Calcular el número de semanas redondeando hacia abajo
    const weekNumber = Math.floor(timeDifference / (7 * 24 * 60 * 60 * 1000)) + 1;
    

    // Obteniendo el contenido del script como texto
    var jsonLdContent = jsonLdScript.textContent || jsonLdScript.innerText;
    // Analiza el contenido JSON-LD para convertirlo en un objeto JavaScript
    var jsonLdObject = JSON.parse(jsonLdContent);
    // Accede a las propiedades del objeto JSON-LD
    type = jsonLdObject["@type"];
    site = siteCurrent;
    identifier = jsonLdObject.identifier;
    articleSection = jsonLdObject.articleSection
    currentDateArticle = jsonLdObject.currentDateArticle;
    // if(type == "WebPage"){

    //     var params = {
    //         usertype: userType,
    //         site: site
    //     };
    //     if(userType === "registrado"){

    //         requestGetPlanSuscrite(site, userIdCurrent, function(status, res){

    //             if(!status){
    //                 if (isPlanExpired(res.plan.date_expired_plan)) {
    //                   console.log('El plan ha expirado.');
    //                   userIdCurrent = "registrado"
    //                   setCookie(userIdCurrent, false, 365);
    //                 } else {
    //                   console.log('El plan está activo.');
    //                   setCookie(userIdCurrent, true, 365);
    //                 }

    //                 var paramsPlanMongo = {
    //                     nameSite: site,
    //                     usertype: userIdCurrent,
    //                     plan: res.plan
    //                 };
    //                 console.log("Plan activo de usuario suscrito::: ",paramsPlanMongo)
    //                 requestPlanMongoPost(paramsPlanMongo, function(status, res){})

    //             }else{

    //                 setCookie(userIdCurrent, false, 365);
    //                 console.log(" Plan activo de usuario registrado::: ", params)
    //                 requestGetPlanSite(params, function(status, res){

    //                     if(!status){
    //                         var paramsPlanMongo = {
    //                             nameSite: site,
    //                             usertype: userType,
    //                             plan: res.plan
    //                         };
    //                         console.log("paramsPlanMongo ",paramsPlanMongo)
    //                         requestPlanMongoPost(paramsPlanMongo, function(status, res){})
    //                     }

    //                 });
    //             }
    //         });

    //     }else{

    //         requestGetPlanSite(params, function(status, res){

    //             if(!status){
    //                 var paramsPlanMongo = {
    //                     nameSite: site,
    //                     usertype: userType,
    //                     plan: res.plan
    //                 };
    //                 requestPlanMongoPost(paramsPlanMongo, function(status, res){})
    //             }
    //         });
    //     }
        
    // }

    if(type == "NewsArticle"){
        if(!jsonLdObject['hasPart'].length) {
           if(jsonLdObject['hasPart']["@type"].includes("Product")){

                var item = jsonLdObject['hasPart'];
                category = item.category
                isAccessibleForFree = item.isAccessibleForFree;
                site = item.name;
           }
        }else{

            jsonLdObject.hasPart.forEach(item => {
              // Verifica si el elemento tiene "@type" y es un "Product"
              if (Array.isArray(item["@type"]) && item["@type"].includes("Product")) {
                category = item.category
                isAccessibleForFree = item.isAccessibleForFree;
                site = item.name;
              }
            });

        }
      
        if(userType === "anonimo"){
           

            // if(jsonLdObject.hasPart.isAccessibleForFree.toLowerCase() === "true"){
            //     validateMetadata({
            //         categoryIsAccesible: categoryIsAccesible, 
            //         userType: userType, 
            //         site: site, 
            //         identifier: identifier, 
            //         currentDateArticle: currentDateArticle, 
            //         weekNumber: weekNumber, 
            //         year: year, 
            //         category: category, 
            //         isAccessibleForFree: isAccessibleForFree
            //     },
            //     userIdCurrent)
            // };
               
            await requestAnonymusPlan().then(res => {
                const {plansProductsCategory, idPlan, userType} = res;
                const productFind = plansProductsCategory.find((element) => element.product.all_product == true);
                // const productFind = plansProductsCategory.find((element) => {
                //     return element.categorysAccess[0].category.product.name.toLowerCase() === articleSection.toLowerCase();
                // });
                if(productFind){
                    if(productFind.categorysAccess.length > 0){
                        const categoryIsAccesible = productFind.categorysAccess.find((element) => element.category.name.toLowerCase() == category.toLowerCase());
                        validateMetadata({
                            categoryIsAccesible: categoryIsAccesible, 
                            userType: userType, 
                            site: site, 
                            identifier: identifier, 
                            currentDateArticle: currentDateArticle, 
                            weekNumber: weekNumber, 
                            year: year, 
                            category: category, 
                            isAccessibleForFree: isAccessibleForFree
                        },
                        userIdCurrent)
                    }
                } else {
                    const productFind = plansProductsCategory.find((element) => element.product.name.toLowerCase() == articleSection.toLowerCase());
                    if(productFind){
                        if(productFind.categorysAccess.length > 0){
                            const categoryIsAccesible = productFind.categorysAccess.find((element) => element.category.name.toLowerCase() == category.toLowerCase());
                            validateMetadata({
                                categoryIsAccesible: categoryIsAccesible, 
                                userType: userType, 
                                site: site, 
                                identifier: identifier, 
                                currentDateArticle: currentDateArticle, 
                                weekNumber: weekNumber, 
                                year: year, 
                                category: category, 
                                isAccessibleForFree: isAccessibleForFree
                            },
                            userIdCurrent)
                        }
                    } else {
                        pintarModa()
                    }
                }
            }).catch(err => {
                pintarModa();
            })
                
        } else {
            await requestPlanUser(siteCurrent).then(res => {
                
                if(res){
                    if(res.userType){
                            userType = res.userType
                    }else{
                            userType = "anonimo"
                    }

                    // const productFind = res.plansProductsCategory.find((element) => {
                    //     return element.categorysAccess[0].category.product.name.toLowerCase() === articleSection.toLowerCase();
                    // });
                    // debugger
                    //const productFind = res.plansProductsCategory.find((element) => element.product.all_product == true);
                    

                    const productFind = res.plansProductsCategory.find((element) => element.categorysAccess[0].category.name.toLowerCase() === category.toLowerCase());
                    if(productFind){
                        if(productFind.categorysAccess.length > 0){
                            const categoryIsAccesible = productFind.categorysAccess.find((element) => element.category.name.toLowerCase() == category.toLowerCase());
                            validateMetadata({
                                categoryIsAccesible: categoryIsAccesible, 
                                userType: userType, 
                                site: site, 
                                identifier: identifier, 
                                currentDateArticle: currentDateArticle, 
                                weekNumber: weekNumber, 
                                year: year, 
                                category: category, 
                                isAccessibleForFree: isAccessibleForFree
                            },
                            userIdCurrent)        
                            }
                    }else{
                        const productFind = res.plansProductsCategory.find((element) => element.product.name.toLowerCase() == articleSection.toLowerCase());
                        if(productFind){
                            if(productFind.categorysAccess.length > 0){
                                const categoryIsAccesible = productFind.categorysAccess.find((element) => element.category.name.toLowerCase() == category.toLowerCase());
                                validateMetadata(
                                    {
                                        categoryIsAccesible: categoryIsAccesible, 
                                        userType: userType, 
                                        site: site, 
                                        identifier: identifier, 
                                        currentDateArticle: currentDateArticle, 
                                        weekNumber: weekNumber, 
                                        year: year, 
                                        category: category, 
                                        isAccessibleForFree: isAccessibleForFree
                                    },
                                    userIdCurrent
                                )

                            }

                    }else{
                        pintarModa()
                    }
                }            
                }
            }
            )         
            .catch(err => {
                setError()
                throw new Error(err)
            });
        }
    }
    
}

function setError(){
    pintarModa();
}

function isPlanExpired(dateExpiredPlan) {
    // Obtén la fecha actual
    const currentDate = new Date();
  
    // Obtén la fecha de expiración del plan desde la cadena proporcionada
    const expirationDate = new Date(dateExpiredPlan);
  
    // Compara las fechas
    return currentDate > expirationDate;
}

function validateMetadata(obj, userIdCurrent){

    if(obj.categoryIsAccesible){
                            
        if(obj.categoryIsAccesible.unlimited == true || obj.categoryIsAccesible.amount >0){

           var params = {
                uniqueId: userIdCurrent,
                userType: obj.userType,
                site: obj.site,
                metadata: {
                    identifier: obj.identifier,
                    isAccessibleForFree: obj.categoryIsAccesible.category.is_accessible_for_free,
                    createDate: obj.currentDateArticle,// currentDate.getTime(), Se debe volver a reemplazar
                    week: obj.weekNumber + "-" + obj.year,
                    category: obj.category
                }
            };
            const getKcId = localStorage.getItem("id_kc");
            getMetadata({
                uniqueId: userIdCurrent,
                userType: obj.userType,
                site: obj.site,
                isAccessibleForFree: obj.isAccessibleForFree,
                amount: obj.categoryIsAccesible.amount,
                category: obj.category,
                duration: obj.categoryIsAccesible.duration,
                unlimited: obj.categoryIsAccesible.unlimited,
                kc_id: getKcId
            }, function(status, listMeta){
                if(!status){
                if(obj.categoryIsAccesible.unlimited == false && listMeta.permissions.avalaible < 1){
                    //validar si en segmento tiene algo disponible
                    if(listMeta.segmentdisponibility){
                        return requestPost(params, function(status, res){
                            pintarModalSegments()
                        });
                    }
                    pintarModa()

                }

                if(obj.categoryIsAccesible.unlimited == true || listMeta.permissions.avalaible > 0){

                    requestPost(params, function(status, res){
                        if(!status){
                          
                        }
                    });

                }
                
            }else{
                pintarModa()
            }});
        }

    }else{
        pintarModa()
    }
}

function VentanaModal(mensaje) {
    // Obtener el elemento modal
    var modal = document.getElementById("myModal");

    // Obtener el elemento donde se muestra el mensaje
    var modalMessage = document.getElementById("modalMessage");

    // Establecer el mensaje en el elemento modal
    modalMessage.innerHTML = mensaje;

    // Mostrar la ventana modal
    modal.style.display = "block";

    // Agregar un evento para cerrar la ventana modal cuando se hace clic fuera de ella
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };
}

// // Define la función de cierre en un ámbito global
function cerrarModal() {
    document.body.classList.remove('modal-open');
      // Oculta el modal
    document.getElementById('miModal').style.display = 'none';
    var modal = document.getElementById("miModal");
    modal.style.display = "none";
}

function abrirModal() {
    document.body.classList.add('modal-open');
    document.getElementById('miModal').style.display = 'block';
    // Obtener la referencia a la modal
    var modal = document.getElementById("miModal");
     modal.style.display = 'flex';
    // Mostrar la modal (puedes aplicar estilos CSS para mostrarla como un modal)
    modal.style.display = "block";
    // Asignar la función de cierre al botón de cerrar
   // var closeButton = modal.querySelector(".close");
   // closeButton.addEventListener("click", cerrarModal);
}

function pintarModa(){
    var styleElement = document.createElement("style");
        // Asigna los estilos de la variable styles al contenido del elemento <style>
        styleElement.innerHTML = styles;
        // Agrega el elemento <style> al head de la página
        document.head.appendChild(styleElement);
        var modalContainer = document.createElement("div");
        modalContainer.innerHTML = template;
        document.body.appendChild(modalContainer);
        var modalContent = document.querySelector(".modal-content");
            abrirModal();
}

var requestGetPlanSite = function(CromaId, callback){
    var xhr = new XMLHttpRequest();

    //TODO crear servicio consulta para obtener el plan del  cusando es anonimos


    xhr.open("GET", admin_api+"/plans/81", true);// 81 // 80
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var users = JSON.parse(xhr.responseText);
                callback(false,users)
                // Iterar sobre los usuarios y agregarlos a la lista ul
            } else {
                console.error("Error en la solicitud:", xhr.status);
                callback(true)
                localStorage.removeItem(CromaId);
            }
        }
    };
    xhr.send();
};

var requestGetPlanSuscrite = function(planName, userId, callback){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", admin_api+"/plans/planuser/"+planName+"/"+userId, true);// 81 // 80
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var users = JSON.parse(xhr.responseText);
                callback(false,users)
                // Iterar sobre los usuarios y agregarlos a la lista ul
            } 
             if (xhr.status === 404) {
                console.error("El usuario no se encuentra suscrito:", xhr.status);
                callback(true)
             }

            if (xhr.status === 500){
                console.error("Error en la solicitud:", xhr.status);
                callback(true)
            }
        }
    };
    xhr.send();
};

var requestGet = function(CromaId){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", admin_api+"/paywall/metadata_paywall", true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var users = JSON.parse(xhr.responseText);
                // Iterar sobre los usuarios y agregarlos a la lista ul
            } else {
                console.error("Error en la solicitud:", xhr.status);
                localStorage.removeItem(CromaId);
            }
        }
    };
    xhr.send();
};

var requestPost = function(data, callback){
    // Convertir los datos a una cadena en formato JSON
    var jsonData = JSON.stringify(data);

    // Crear una nueva solicitud XMLHttpRequest
    var xhr = new XMLHttpRequest();

    // Configurar la solicitud POST
    xhr.open("POST", admin_api+"/paywall/metadata_paywall", true);

    // Establecer el encabezado Content-Type a application/json
    xhr.setRequestHeader("Content-Type", "application/json");
    //VentanaModal("Debes adquirir un plan para poder continuar");
    // abrirModal();
    // Configurar la función de devolución de llamada cuando la solicitud esté lista
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 201) {
                var response = JSON.parse(xhr.responseText);
                var pagesList = JSON.parse(response.pages);
                callback(false,response.avalaible)
            } else {
                callback(true)
                console.error("Error en la solicitud:", xhr.status);
                // Manejar errores aquí
            }
        }
    };
    // Enviar los datos en el cuerpo de la solicitud
    xhr.send(jsonData);
};

var getMetadata = function(data, callback){
    var xhr = new XMLHttpRequest();
    // Configurar la solicitud GET
    var url = admin_api+"/paywall/metadata_paywall" 
    + "?uniqueId=" + encodeURIComponent(data.uniqueId) 
    + "&userType=" + encodeURIComponent(data.userType)
    + "&site=" + encodeURIComponent(data.site)
    + "&isAccessibleForFree=" + encodeURIComponent(data.isAccessibleForFree)
    + "&amount=" + encodeURIComponent(data.amount)
    + "&category=" + encodeURIComponent(data.category)
    + "&duration=" + encodeURIComponent(data.duration)
    + "&unlimited=" + encodeURIComponent(data.unlimited)
    + "&kc_id=" + encodeURIComponent(data.kc_id)

    xhr.open("GET", url, true);

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
               var response = JSON.parse(xhr.responseText);
                callback(false,response)
                // Iterar sobre los usuarios y agregarlos a la lista ul
            } else {
                console.error("Error en la solicitud:", xhr.status);
                callback(true)
            }
        }
    };
    xhr.send();
};

const requestAnonymusPlan = async () => {
    const options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    };
    const response = await fetch(
        `${admin_api}/paywall/getAnonimoPlan`, 
        options
    );
    if (!response.ok) {
        throw new Error("Se ha producido un nuevo error");
    }

    const data = await response.json();
    return data;
}

const requestPlanUser = async (siteCurrent) => {
    const getToken = localStorage.getItem(siteCurrent+"_token");
    const jwt = await decodedJWT(getToken);
    const options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${getToken}`
        }
    };
    const response = await fetch(
        `${admin_api}/paywall/getPlanByUserId?userId=${jwt.sub}`, 
        options
    );
    if (!response.ok) {
        throw new Error("Se ha producido un nuevo error");
    }

    const data = await response.json();
    return data;
}

const requestPlanMongoPost = function(data, callback){
    var jsonData = JSON.stringify(data);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", admin_api+"/paywall/plan_paywall", true);

    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 201) {
               var plan = JSON.parse(xhr.responseText);

                var response = JSON.parse(xhr.responseText);
                callback(false,plan)
                // Procesar la respuesta aquí
            } else {
                console.error("Error en la solicitud:", xhr.status);
                callback(true)
                // Manejar errores aquí
            }
        }
    };
    // Enviar los datos en el cuerpo de la solicitud
    xhr.send(jsonData);
};

// // Función para generar un identificador único
function generateUniqueId() {
    return "ID_" + Math.random().toString(36).substring(2, 15);
}
  
// Función para obtener o crear un identificador único y almacenarlo en una cookie
function getOrSetUniqueId() {
    let uniqueId = getCookie("uniqueId");
    if (!uniqueId) {
        uniqueId = generateUniqueId();
        setCookie("uniqueId", uniqueId, 365); // Almacena la cookie durante 365 días
    }
    return uniqueId;
}


function setCookie(name, value, days) {
    const expires = new Date();
    expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
    document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
}
  

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(";").shift();
}


function validarCookie(nombreCookie) {
  // Obtener todas las cookies presentes en el documento
  const cookies = document.cookie.split(';');

  // Buscar la cookie por su nombre
  const cookieEncontrada = cookies.find(cookie => {
    const [cookieName, cookieValue] = cookie.split('=').map(c => c.trim());
    return cookieName === nombreCookie;
  });

  // Validar si se encontró la cookie
  if (cookieEncontrada) {
    return true;
  } else {
    return false;
  }
}

function pintarModalSegments() {
    var styleElement = document.createElement("style");
    // Asigna los estilos de la variable styles al contenido del elemento <style>
    styleElement.innerHTML = stylesModalSegments;
    // Agrega el elemento <style> al head de la página
    document.head.appendChild(styleElement);
    var modalContainer = document.createElement("div");
    modalContainer.innerHTML = templateModalSegments;
    document.body.appendChild(modalContainer);
    var modalContent = document.querySelector(".modal-segment-content");
        abrirModalSegmentos();     

    }

    // // Define la función de cierre en un ámbito global
function cerrarModalSegmentos() {
    document.body.classList.remove('modal-segments-open');
      // Oculta el modal
    document.getElementById('modalSegments').style.display = 'none';
    var modal = document.getElementById("modalSegments");
    modal.style.display = "none";
}


function abrirModalSegmentos() {
    document.body.classList.add('modal-segments-open');
    document.getElementById('modalSegments').style.display = 'block';
    // Obtener la referencia a la modal
    var modal = document.getElementById("modalSegments");
     modal.style.display = 'flex';
    // Mostrar la modal (puedes aplicar estilos CSS para mostrarla como un modal)
     modal.style.display = "block";
    // Asignar la función de cierre al botón de cerrar
   // var closeButton = modal.querySelector(".close");
   // closeButton.addEventListener("click", cerrarModal);
}

const templateModalSegments =
"<div id='modalSegments' class='modal-segments'>" +
"<div class='modal-segment-content'>" +
//"<span class='close' onclick='cerrarModal()'>&times;</span>" +
"<div class='plan-segment-message'>¡Gracias por disfrutar de nuestro contenido!</div>" +
"<div class='content-segment-info'>" +
    "<p class='text-segment-descriptive'> Parece que has alcanzado el límite de visualizaciones gratuitas.</p>"+
    "<p class='text-segment-call-action'>¡Por pertenecer a uno de nuestros segmentos puedes continuar disfrutando nuestro contenido!</p>"+
    "<div class='buttons-segment-container'>"+
    "<button onclick='cerrarModalSegmentos()'>Aceptar</button>"+
    "</div>" +
"</div>"+
'</div>' +
'</div>';

const stylesModalSegments = `
.content-segment-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 10px 40px;
}

.text-segment-descriptive{
    font-size: 16px;
    line-height: 22px;
    word-break: keep-all;
    overflow-wrap: break-word;
    hyphens: none;
    margin: 5px 0;
    text-align: center;
    font-weight: 400;
}

.buttons-segment-container {
    margin: 15px 0px;
    width: 100%;
    justify-content: center;
    display: flex;
}

.buttons-segment-container> button {
    width: 220px;
    border-radius: 8px;
    margin: 0px 15px;
    padding: 10px;
    cursor: pointer;
}

.buttons-segment-container > button:first-child {
    background-color: #fff;
    font-size: 14px;
    border: 1px solid #C9D315;
    font-weight: 700;
    color: #000;
}

.buttons-segment-container > button:first-child:hover {
    background-color: #C9D315;
    font-size: 14px;
    border: 1px solid #C9D315;
    font-weight: 700;
    color: #000;
}

.text-segment-call-action{
    margin: 5px 0;
    font-size: 18px;
    text-align: center;
    line-height: 28px;
    font-weight: 600;
}

.color-box {
width: calc(33.33% - 10px);
height: 300px;
display: inline-flex;
flex-direction: column;
align-items: center;
justify-content: center;
margin-right: 10px;
box-sizing: border-box;
text-align: center;
border: 1px solid #888; /* Borde de 2px */
margin-bottom: 10px; /* Espacio entre los divs de plan */
position: relative; /* Para que la posición absoluta del icono sea relativa a este div */
}


.plan-segment-message {
    text-align: center;
    font-size: 18px;
    margin-bottom: 20px;
    font-family: sans-serif;
    font-style: inherit;
    font-weight: bold;
    background-color: #C9D315;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
    padding: 16px;
}

.color-box span {
color: white; /* Ajusta el color del texto según el fondo del div */
}

.modal-segments {
display: none;
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-color: rgba(0, 0, 0, 0.7);
z-index: 9999
}

.modal-segment-content {
    background-color: #fefefe;
    margin: 10% auto;
    border: 1px solid #888;
    width: 80%;
    position: relative;
    border-radius: 16px;
    border-bottom: 8px solid black;
}

.close {
position: absolute;
top: 0;
right: 0;
padding: 10px;
cursor: pointer;
}

.modal-segments-open {
overflow: hidden;
}
`;

  