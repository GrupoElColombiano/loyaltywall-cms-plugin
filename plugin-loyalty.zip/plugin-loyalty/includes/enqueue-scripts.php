<?php

function cargar_loyaltywall_script_js() {
    wp_enqueue_script(
        'loyaltywall-script',
        plugin_dir_url(__DIR__) . 'public/assets/js/paywall.js',
        array(),
        '1.0',
        true
    );

    $datos_js = array(
        'url_base' => get_option('plugin_loyaltywall_url_base', ''),
        'url_base_loyaltiwall'  => get_option('plugin_loyaltywall_url_base_loyaltiwall', '')
    );

    wp_localize_script('loyaltywall-script', 'configuracion', $datos_js);
}

function segments_script_js (){
        wp_enqueue_script(
            'segments-script',
            plugin_dir_url(__DIR__) . 'public/assets/js/segments.js',
            array(),
            '1.0',
            false
        );
        $datos_js = array(
            'url_api_admin' => get_option('plugin_loyaltywall_url_backend_admin', '')
        );

        wp_localize_script('segments-script', 'configuracion', $datos_js);
}

add_action('wp_enqueue_scripts', 'segments_script_js');

